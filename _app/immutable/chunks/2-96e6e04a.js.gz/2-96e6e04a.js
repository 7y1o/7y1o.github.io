import{default as t}from"../components/pages/_page.svelte-71714d7e.js";export{t as component};
