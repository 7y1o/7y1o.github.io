import{_ as r}from"./_layout-f27cf537.js";import{default as t}from"../components/layout.svelte-802a21b1.js";export{t as component,r as shared};
