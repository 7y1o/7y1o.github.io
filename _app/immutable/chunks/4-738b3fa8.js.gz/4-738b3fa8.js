import{default as t}from"../components/pages/skills/_page.svelte-23149acf.js";export{t as component};
