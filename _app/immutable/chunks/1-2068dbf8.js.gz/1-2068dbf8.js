import{default as t}from"../components/error.svelte-dd95b703.js";export{t as component};
