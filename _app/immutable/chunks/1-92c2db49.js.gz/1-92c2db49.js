import{default as t}from"../components/error.svelte-5c652dcb.js";export{t as component};
