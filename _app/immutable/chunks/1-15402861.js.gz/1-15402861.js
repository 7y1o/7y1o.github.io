import{default as t}from"../components/error.svelte-6647dc1b.js";export{t as component};
