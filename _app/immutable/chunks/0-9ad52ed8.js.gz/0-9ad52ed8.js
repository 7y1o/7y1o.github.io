import{_ as r}from"./_layout-f27cf537.js";import{default as t}from"../components/layout.svelte-34b45f3a.js";export{t as component,r as shared};
