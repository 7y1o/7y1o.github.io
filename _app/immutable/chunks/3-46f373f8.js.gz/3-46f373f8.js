import{default as t}from"../components/pages/projects/_page.svelte-452cb5b9.js";export{t as component};
