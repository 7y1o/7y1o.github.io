import{default as t}from"../components/pages/projects/_page.svelte-8899422c.js";export{t as component};
