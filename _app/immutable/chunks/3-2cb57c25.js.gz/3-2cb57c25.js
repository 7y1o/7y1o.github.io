import{default as t}from"../components/pages/projects/_page.svelte-94d471ea.js";export{t as component};
