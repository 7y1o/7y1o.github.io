import{default as t}from"../components/pages/skills/_page.svelte-764dbd91.js";export{t as component};
