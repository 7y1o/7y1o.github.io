import{default as t}from"../components/pages/skills/_page.svelte-da216aff.js";export{t as component};
