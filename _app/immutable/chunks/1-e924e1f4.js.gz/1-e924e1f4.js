import{default as t}from"../components/error.svelte-b12243ec.js";export{t as component};
