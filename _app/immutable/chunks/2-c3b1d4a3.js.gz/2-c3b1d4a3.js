import{default as t}from"../components/pages/_page.svelte-1f9f8356.js";export{t as component};
