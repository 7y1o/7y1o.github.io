import{p}from"../../chunks/_layout-f27cf537.js";export{p as prerender};
